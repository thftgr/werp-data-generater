연결실패시 파일에는 유지 
java -jar "werp-1.0-SNAPSHOT.jar" 7e2757b7-badc-4303-8cd0-2eefa9d78e3b

연결실패시 파일에서도 삭제
java -jar "werp-1.0-SNAPSHOT.jar" 7e2757b7-badc-4303-8cd0-2eefa9d78e3b -d


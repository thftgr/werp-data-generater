java -Xms4G -jar "werp-1.0-SNAPSHOT.jar" 7e2757b7-badc-4303-8cd0-2eefa9d78e3b

동시에 다중으로 생성할거면 

java -Xms4G -jar "werp-1.0-SNAPSHOT.jar" 7e2757b7-badc-4303-8cd0-2eefa9d78e3b 7e2757b7-badc-4303-8cd0-2eefa9d78e3b 

식으로 이어서 넣는다
